﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LivreMvc.Models
{
  

    public class Livre
    {
        public int ID { get; set; }
        [StringLength(150, MinimumLength = 3)]
        public string Title { get; set; }
        [StringLength(100, MinimumLength = 3)]
        public string Editeur { get; set; }
        [StringLength(100, MinimumLength = 3)]
        public string Auteur { get; set; }
        public DateTime ParutionDate { get; set; }
        public Livre(int id, string title, string auteur, string editeur, DateTime parutionDate)
        {
            ID = id;
            Title = title;
            Editeur = editeur;
            Auteur = auteur;
            ParutionDate = parutionDate;

        }
        public Livre()
        {


        }
    }

}