﻿using LivreMvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LivreMvc.Controllers
{
    public class LivreController : Controller
    {
        static Livre[] movies = {  new Livre(1, "Vital !", " Frédéric Saldmann ", " Frédéric Saldmann ", DateTime.Parse("09/01/2019")),
            new Livre(2, " Les jumeaux de Piolenc ", "Sandrine Destombes ", "Hugo Roman ", DateTime.Parse("03/05/2018")),
            new Livre(3, "Sapiens : une brève histoire de l’humanité", "Yuval Noah Harari ", "Albin Michel ", DateTime.Parse("02/09/2015")),
            new Livre(4, " Devenir", "Michèle Obama ", " Fayard", DateTime.Parse("13/11/2018")),
      };

        // GET: Livre
        public ActionResult Index(string movieGenre, string searchString)
        {
            var GenreLst = new List<string>();
            foreach (Livre m in movies)
            {
                GenreLst.Add(m.Editeur);
            }

            ViewBag.movieGenre = new SelectList(GenreLst.Distinct());
            var list = movies.ToList();

            if (!String.IsNullOrEmpty(searchString))
            {
                list = movies.Where(s => s.Title.Contains(searchString)).ToList();

            }
            var list1 = list;
            if (!String.IsNullOrEmpty(movieGenre))
            {
                list1 = list.Where(x => x.Editeur.Contains(movieGenre)).ToList();
            }

            return View(list1);
        }


        // GET: Livre/Details/5
        public ActionResult Details(int id)
        {
            Livre detail = new Livre();
            foreach (Livre m in movies)
            {
                if (m.ID == id)
                {
                    detail = m;
                    break;
                }
            }

            return View(detail);
        }
        // GET:  Livre/Creer
        public ActionResult Creer()
        {



            return View();
        }

        // POST: Livre/Creer
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Creer([Bind(Include = "ID,Title,Editeur,Auteur,ParutionDate")] Livre movie)
        {
            List<Livre> list = movies.ToList();
            list.Add(movie);
            movies = list.ToArray();

            return RedirectToAction("Index");
        }
        // GET: Livre/Edit/5
        public ActionResult Edit(int id)
        {
            Livre detail = new Livre();
            foreach (Livre m in movies)
            {
                if (m.ID == id)
                {
                    detail = m;
                    break;
                }
            }

            return View(detail);
        }

        // POST: Livre/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Title,Editeur,Auteur,ParutionDate") ]Livre movie)
        {
            Livre detail = new Livre();
            foreach (Livre m in movies)
            {
                if (m.ID == movie.ID)
                {
                    m.Auteur= movie.Auteur;
                    m.Editeur = movie.Editeur;
                    m.Title = movie.Title;
                    m.ParutionDate = movie.ParutionDate;
                    break;
                }
            }

            return View(movie);
        }

        // GET: Livre/Delete/5
        public ActionResult Delete(int id)
        {

            Livre detail = new Livre();
            foreach (Livre m in movies)
            {
                if (m.ID == id)
                {
                    detail = m;
                    break;
                }
            }

            return View(detail);
        }

        // POST: /Livre/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed([Bind(Include = "ID,Title,Editeur,Auteur,ParutionDate")] Livre movie)
        {

            int delete = 0;

            for (int i = 0; i < movies.Length; i++)
            {
                if (movies[i].ID == movie.ID
                )
                {
                    delete = i;
                    break;
                }
            }
            List<Livre> list = movies.ToList();
            list.RemoveAt(delete);
            movies = list.ToArray();

            return RedirectToAction("Index");
        }
    }

}
