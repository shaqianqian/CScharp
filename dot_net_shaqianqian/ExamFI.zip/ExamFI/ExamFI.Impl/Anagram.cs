﻿using System;

namespace ExamFI.Impl
{
    public class Anagram
    {
        public bool IsAnagram(string firstWord, string secondWord)
        {
            firstWord = firstWord.ToLower();
            secondWord = secondWord.ToLower();
            char[] S1 = firstWord.ToCharArray();
            char[] S2 = secondWord.ToCharArray();
            bool isE = true;
            foreach (char c in S1) {
                if (!secondWord.Contains(c)) {
                    isE = false;
                }

            }
            foreach (char c in S2)
            {
                if (!firstWord.Contains(c))
                {
                    isE = false;
                }

            }
            return isE;

        }
    }
}
