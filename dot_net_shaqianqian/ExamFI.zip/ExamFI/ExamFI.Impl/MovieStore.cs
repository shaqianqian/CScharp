﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamFI.Impl
{
    public class MovieStore
    {
        private readonly List<Movie> movies = new List<Movie>
        {
            new Movie
            {
                Title = "Forest Gump", MainActors = new List<string>
                {
                    "Tom Hanks",
                    "Gary Sinise",
                    "Robin Wright"
                },
                ReleasedDate = new DateTime(1994, 10, 05)
            },
            new Movie
            {
                Title = "La ligne verte", MainActors = new List<string>
                {
                    "Tom Hanks",
                    "David Morse"
                },
                ReleasedDate = new DateTime(2000, 03, 01)
            },
            new Movie
            {
                Title = "Le Parrain", MainActors = new List<string>
                {
                    "Marlon Brando",
                    "Al Pacino",
                    "James Caan"
                },
                ReleasedDate = new DateTime(1972, 03, 15)
            },
            new Movie
            {
                Title = "Gran Torino", MainActors = new List<string>
                {
                    "Clint Eastwood",
                    "Bee Vang"
                },
                ReleasedDate = new DateTime(2009, 02, 25)
            },

            new Movie
            {
                Title = "Arrête-moi si tu peux", MainActors = new List<string>
                {
                    "Leonardo DiCaprio",
                    "Tom Hanks"
                },
                ReleasedDate = new DateTime(2003, 02, 12)
            }

        };

        public IEnumerable<Movie> GetAllMovies()
        {
            return from n in movies select n;
        }

        public IEnumerable<Movie> GetAllMoviesByDate()
        {
            var newNumbers = from n in movies orderby n.ReleasedDate select n;
            return newNumbers;
        }

        public IEnumerable<Movie> GetAllMoviesWithTomHanks()
        {
            return from n in movies where n.MainActors.Contains("Tom Hanks") select n;
        }

        public IEnumerable<Movie> GetAllMoviesWithTomHanksAfterYear()
        {
            return from n in movies where n.MainActors.Contains("Tom Hanks")&&n.ReleasedDate.Year>=2000 select n;
        }
    }

    public class Movie
    {
        public string Title { get; set; }
        public IEnumerable<string> MainActors { get; set; }
        public DateTime ReleasedDate { get; set; }
    }
}
