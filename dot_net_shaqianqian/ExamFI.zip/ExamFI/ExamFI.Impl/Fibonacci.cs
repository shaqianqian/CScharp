﻿using System;
using System.Collections.Generic;

namespace ExamFI.Impl
{
    public class Fibonacci
    {
        public IEnumerable<int> GetFibonacciNumbers(int limit)
        {
            List<int> fs = new List<int>();
            fs.Add(0);
            int prv = 0, pre = 1, trm=0, i;

           while(trm<100)
            {
                trm = prv + pre;
                Console.Write("  {0}  ", trm);
                fs.Add(trm);
                prv = pre;
                pre = trm;
            }
            return fs;
        }

    


        }

        
    }


    
