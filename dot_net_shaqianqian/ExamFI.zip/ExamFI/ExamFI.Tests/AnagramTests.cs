﻿using ExamFI.Impl;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExamFI.Tests
{
    [TestClass]
    public class AnagramTests
    {
        [TestMethod]
        [Description("Write a program that takes two words as an argument and returns true if they are anagrams and false otherwise. Anagram are words that contain the exact same letters")]
        public void ChecksIfAWordIsAnAnagram()
        {
            // Arrange
            var subject = new Anagram();

            // Act
            var isChienNicheAnAnagram = subject.IsAnagram("Chien", "Niche");
            var isIroniqueOniriqueAnAnagram = subject.IsAnagram("Ironique", "Onirique");
            var isEcranClavierAnAnagram = subject.IsAnagram("Ecran", "Clavier");

            // Assert
            Assert.IsTrue(isChienNicheAnAnagram);
            Assert.IsTrue(isIroniqueOniriqueAnAnagram);
            Assert.IsFalse(isEcranClavierAnAnagram);
        }
    }
}
