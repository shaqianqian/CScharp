﻿using System.Linq;
using ExamFI.Impl;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExamFI.Tests
{
    [TestClass]
    public class FibonacciTests
    {
        [TestMethod]
        [Description("Display the fibonacci numbers below a defined limit.")]
        public void Fibonacci()
        {
            // Arrange
            var subject = new Fibonacci();

            // Act
            var numbers = subject.GetFibonacciNumbers(100);

            // Assert
            Assert.AreEqual(12, numbers.Count());
            Assert.IsTrue(numbers.Contains(0));
            Assert.IsTrue(numbers.Contains(1));
            Assert.IsTrue(numbers.Contains(2));
            Assert.IsTrue(numbers.Contains(3));
            Assert.IsTrue(numbers.Contains(5));
            Assert.IsTrue(numbers.Contains(8));
            Assert.IsTrue(numbers.Contains(13));
            Assert.IsTrue(numbers.Contains(21));
            Assert.IsTrue(numbers.Contains(34));
            Assert.IsTrue(numbers.Contains(55));
            Assert.IsTrue(numbers.Contains(89));
        }
    }
}
