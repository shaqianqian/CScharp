﻿using System.Linq;
using ExamFI.Impl;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExamFI.Tests
{
    [TestClass]
    public class MovieStoreTests
    {
        [TestMethod]
        public void GetAllMovies()
        {
            // Arrange
            var subject = new MovieStore();

            // Act
            var movies = subject.GetAllMovies();

            // Assert
            Assert.AreEqual(5, movies.Count());
        }

        [TestMethod]
        public void GetAllMoviesOrderedByDate()
        {
            // Arrange
            var subject = new MovieStore();

            // Act
            var movies = subject.GetAllMoviesByDate();

            // Assert
            Assert.AreEqual(5, movies.Count());
            Assert.AreEqual("Le Parrain", movies.ElementAt(0).Title);
            Assert.AreEqual("Forest Gump", movies.ElementAt(1).Title);
            Assert.AreEqual("La ligne verte", movies.ElementAt(2).Title);
            Assert.AreEqual("Arrête-moi si tu peux", movies.ElementAt(3).Title);
            Assert.AreEqual("Gran Torino", movies.ElementAt(4).Title);
        }

        [TestMethod]
        public void GetAllMoviesWithTomHanks()
        {
            // Arrange
            var subject = new MovieStore();

            // Act
            var movies = subject.GetAllMoviesWithTomHanks();

            // Assert
            Assert.AreEqual(3, movies.Count());
            Assert.AreEqual("Forest Gump", movies.ElementAt(0).Title);
            Assert.AreEqual("La ligne verte", movies.ElementAt(1).Title);
            Assert.AreEqual("Arrête-moi si tu peux", movies.ElementAt(2).Title);
        }

        [TestMethod]
        public void GetAllMoviesWithTomHanksAfterYear2000()
        {
            // Arrange
            var subject = new MovieStore();

            // Act
            var movies = subject.GetAllMoviesWithTomHanksAfterYear();

            // Assert
            Assert.AreEqual(2, movies.Count());
            Assert.AreEqual("La ligne verte", movies.ElementAt(0).Title);
            Assert.AreEqual("Arrête-moi si tu peux", movies.ElementAt(1).Title);
        }
    }
}
